package com.example.ben10launcher.data

/** Persisted user choices. */
data class LauncherSettings(
    val folderUri: String? = null,
    val emulatorPackage: String = Emulators.DEFAULT_PACKAGE,
)

data class EmulatorOption(val label: String, val packageName: String)

object Emulators {
    const val DEFAULT_PACKAGE = "com.winlator"
    const val DOWNLOAD_URL = "https://github.com/brunodev85/winlator/releases"

    val known = listOf(
        EmulatorOption("Winlator", "com.winlator"),
        EmulatorOption("Winlator Cmod", "com.winlator.cmod"),
    )

    fun labelFor(pkg: String): String =
        known.firstOrNull { it.packageName == pkg }?.label ?: "emulator"
}

enum class FolderStatus {
    NONE,
    PERMISSION_LOST,
    FOLDER_MISSING,
    NOT_FOUND,
    POSSIBLE,
    VALID,
}

data class FolderScanResult(
    val status: FolderStatus = FolderStatus.NONE,
    val message: String = "No game folder selected yet.",
    val displayName: String? = null,
    val primaryExe: String? = null,
    val exeCount: Int = 0,
    /** Real filesystem path (e.g. /storage/emulated/0/Games/Ben10) if it can be derived. */
    val realPath: String? = null,
)

/** Static game info shown in the app. Edit freely. */
object GameInfo {
    const val TITLE = "Ben 10"
    const val YEAR = "2017"
    const val PLATFORM = "Windows PC"
    const val PUBLISHER = "Outright Games"
    const val DESCRIPTION =
        "Action-adventure game based on the Ben 10 series. This launcher does not include, " +
            "download or modify any game files. It only opens your own copy in an emulator."

    /** Starting points to try inside the emulator. These are NOT verified results. */
    val suggestedSettings = listOf(
        "Container" to "Wine 9.x, 64-bit",
        "Graphics driver" to "Turnip (Adreno) or Mali Vulkan",
        "DirectX wrapper" to "DXVK",
        "Resolution" to "1280x720, 30 FPS cap",
    )
}
