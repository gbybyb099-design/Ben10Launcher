package com.example.ben10launcher.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Omnitrix = darkColorScheme(
    primary = Color(0xFF4CFF3A),
    onPrimary = Color(0xFF042100),
    primaryContainer = Color(0xFF0F3A0A),
    onPrimaryContainer = Color(0xFFB8FFAE),
    secondary = Color(0xFF9BD68F),
    background = Color(0xFF0B0F0A),
    onBackground = Color(0xFFE2E8DF),
    surface = Color(0xFF0B0F0A),
    onSurface = Color(0xFFE2E8DF),
    surfaceVariant = Color(0xFF1A221A),
    onSurfaceVariant = Color(0xFFB6C2B3),
    error = Color(0xFFFF6B6B),
)

@Composable
fun Ben10Theme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Omnitrix, content = content)
}
