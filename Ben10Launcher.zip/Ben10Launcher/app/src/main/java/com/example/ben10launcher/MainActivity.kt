package com.example.ben10launcher

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.example.ben10launcher.ui.LauncherScreen
import com.example.ben10launcher.ui.theme.Ben10LauncherTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            Ben10LauncherTheme {
                LauncherScreen()
            }
        }
    }
}
