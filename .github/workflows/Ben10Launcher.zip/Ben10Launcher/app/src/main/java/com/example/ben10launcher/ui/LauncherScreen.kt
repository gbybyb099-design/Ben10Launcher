package com.example.ben10launcher.ui

import android.text.format.Formatter
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ben10launcher.LauncherViewModel
import com.example.ben10launcher.data.CompatStatus
import com.example.ben10launcher.data.EmulatorInfo
import com.example.ben10launcher.data.EmulatorLauncher
import com.example.ben10launcher.data.GameInfo

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LauncherScreen(vm: LauncherViewModel = viewModel()) {
    val state by vm.state.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) vm.onFolderPicked(uri)
    }

    // Re-check for Winlator and folder access whenever the user returns to the app.
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        vm.refreshEmulator()
        vm.rescan()
    }

    LaunchedEffect(state.message) {
        state.message?.let {
            snackbar.showSnackbar(it)
            vm.consumeMessage()
        }
    }

    val hasFolder = state.treeUri != null
    val canLaunch = hasFolder && state.emulator != null &&
        state.info?.status != CompatStatus.INACCESSIBLE

    Scaffold(
        topBar = { TopAppBar(title = { Text("Ben 10 Launcher", fontWeight = FontWeight.Bold) }) },
        snackbarHost = { SnackbarHost(snackbar) },
        bottomBar = {
            Surface(tonalElevation = 3.dp) {
                Button(
                    onClick = vm::launchEmulator,
                    enabled = canLaunch,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                        .navigationBarsPadding()
                        .height(54.dp),
                ) {
                    Icon(Icons.Filled.PlayArrow, null)
                    Spacer(Modifier.width(8.dp))
                    Text(state.emulator?.let { "Launch ${it.label}" } ?: "Launch")
                }
            }
        },
    ) { padding ->
        Column(
            Modifier
                .padding(padding)
                .padding(horizontal = 16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            FolderCard(
                path = state.filePath ?: state.treeUri?.lastPathSegment,
                hasFolder = hasFolder,
                onPick = { picker.launch(state.treeUri) },
                onClear = vm::clearFolder,
            )
            if (hasFolder) {
                GameInfoCard(state.info, state.scanning, vm::rescan)
                CompatibilityCard(state.info?.status ?: CompatStatus.NO_FOLDER)
            }
            EmulatorCard(
                current = state.emulator,
                apps = state.apps,
                isCustom = state.customEmulator.isNotBlank(),
                onSelect = vm::setCustomEmulator,
                onReset = vm::resetEmulator,
                onDownload = vm::openDownloadPage,
            )
            Text(
                "This app doesn't include or download any game files. Select your own legally obtained copy.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(8.dp))
        }
    }
}

@Composable
private fun SectionCard(
    title: String,
    icon: @Composable () -> Unit,
    content: @Composable ColumnScope.() -> Unit,
) {
    ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                icon()
                Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            }
            content()
        }
    }
}

@Composable
private fun FolderCard(path: String?, hasFolder: Boolean, onPick: () -> Unit, onClear: () -> Unit) {
    SectionCard("Game folder", { Icon(Icons.Filled.Folder, null, tint = MaterialTheme.colorScheme.primary) }) {
        Text(
            path ?: "No folder selected",
            style = MaterialTheme.typography.bodyMedium,
            maxLines = 3,
            overflow = TextOverflow.Ellipsis,
            color = if (hasFolder) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = onPick) { Text(if (hasFolder) "Change folder" else "Select folder") }
            if (hasFolder) OutlinedButton(onClick = onClear) { Text("Remove") }
        }
    }
}

@Composable
private fun GameInfoCard(info: GameInfo?, scanning: Boolean, onRescan: () -> Unit) {
    val ctx = LocalContext.current
    SectionCard("Game information", { Icon(Icons.Filled.Info, null, tint = MaterialTheme.colorScheme.primary) }) {
        if (info == null) {
            if (scanning) LinearProgressIndicator(Modifier.fillMaxWidth()) else Text("Scanning…")
        } else {
            InfoRow("Folder", info.folderName)
            InfoRow("Executable", info.executables.firstOrNull() ?: "Not found in root")
            InfoRow("Engine folder", if (info.hasEngineDir) "Found" else "Missing")
            InfoRow("Game content", if (info.hasGameDir) "Found" else "Missing")
            InfoRow(
                "Pak files",
                if (info.pakCount > 0) "${info.pakCount} (${Formatter.formatFileSize(ctx, info.pakBytes)})" else "None found",
            )
            TextButton(onClick = onRescan) {
                Icon(Icons.Filled.Refresh, null)
                Spacer(Modifier.width(6.dp))
                Text("Rescan")
            }
        }
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.width(12.dp))
        Text(value, style = MaterialTheme.typography.bodyMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun CompatibilityCard(status: CompatStatus) {
    val (headline, detail) = when (status) {
        CompatStatus.LOOKS_VALID -> "Looks like a valid install" to
            "Expected files were found. Performance depends on your device and Winlator setup (a Vulkan/Turnip driver is recommended)."
        CompatStatus.PARTIAL -> "Partially recognized" to
            "Some expected files are missing. Select the folder that contains the game's .exe and Engine folder."
        CompatStatus.NOT_RECOGNIZED -> "Not recognized" to
            "This doesn't look like the Ben 10 (2017) PC game folder."
        CompatStatus.INACCESSIBLE -> "Folder not accessible" to "Access was lost. Select the folder again."
        CompatStatus.NO_FOLDER -> "No folder" to "Select a folder first."
    }
    val ok = status == CompatStatus.LOOKS_VALID
    SectionCard("Compatibility", {
        Icon(
            if (ok) Icons.Filled.CheckCircle else Icons.Filled.Warning, null,
            tint = if (ok) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
        )
    }) {
        Text(headline, fontWeight = FontWeight.SemiBold)
        Text(detail, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(
            "Windows games run through emulation and are not guaranteed to work.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun EmulatorCard(
    current: EmulatorInfo?,
    apps: List<EmulatorInfo>,
    isCustom: Boolean,
    onSelect: (String) -> Unit,
    onReset: () -> Unit,
    onDownload: () -> Unit,
) {
    var showPicker by remember { mutableStateOf(false) }
    SectionCard("Emulator / runtime", { Icon(Icons.Filled.Memory, null, tint = MaterialTheme.colorScheme.primary) }) {
        Text(
            if (current != null) current.label else "No emulator found",
            fontWeight = FontWeight.SemiBold,
            color = if (current != null) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
        )
        Text(
            if (current != null) current.packageName else "Choose the app you use to run PC games (for example Winlator Mali).",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { showPicker = true }) { Text("Choose app") }
            if (isCustom) OutlinedButton(onClick = onReset) { Text("Auto") }
        }
        if (current == null) TextButton(onClick = onDownload) { Text("Get Winlator") }
    }

    if (showPicker) {
        val sorted = apps.sortedByDescending { EmulatorLauncher.isWinlatorLike(it) }
        AlertDialog(
            onDismissRequest = { showPicker = false },
            title = { Text("Choose emulator app") },
            text = {
                LazyColumn {
                    items(sorted, key = { it.packageName }) { app ->
                        Column(
                            Modifier
                                .fillMaxWidth()
                                .clickable { onSelect(app.packageName); showPicker = false }
                                .padding(vertical = 10.dp)
                        ) {
                            Text(app.label, fontWeight = FontWeight.Medium)
                            Text(app.packageName, style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showPicker = false }) { Text("Cancel") } },
        )
    }
}
