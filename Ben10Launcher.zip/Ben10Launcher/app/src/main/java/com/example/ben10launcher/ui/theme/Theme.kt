package com.example.ben10launcher.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColors = darkColorScheme(
    primary = Color(0xFF5BE37D),
    onPrimary = Color(0xFF00390F),
    primaryContainer = Color(0xFF00531A),
    onPrimaryContainer = Color(0xFF79FF95),
    background = Color(0xFF0E1410),
    onBackground = Color(0xFFDFE4DC),
    surface = Color(0xFF0E1410),
    onSurface = Color(0xFFDFE4DC),
)

private val LightColors = lightColorScheme(
    primary = Color(0xFF006E26),
    onPrimary = Color.White,
    primaryContainer = Color(0xFF79FF95),
    onPrimaryContainer = Color(0xFF002106),
    background = Color(0xFFF7FBF3),
    onBackground = Color(0xFF191D18),
    surface = Color(0xFFF7FBF3),
    onSurface = Color(0xFF191D18),
)

@Composable
fun Ben10LauncherTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        content = content,
    )
}
