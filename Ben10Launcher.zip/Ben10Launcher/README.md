# Ben 10 Launcher

Kotlin + Jetpack Compose + Material 3 launcher for **your own legally obtained** Ben 10 (2017) PC game.
It contains no game files and does not download anything. It opens Winlator (or another emulator).

## Open and run
1. Android Studio Ladybug (2024.2) or newer, JDK 17.
2. File > Open > select the `Ben10Launcher` folder, then let Gradle sync
   (Android Studio creates the missing `gradle-wrapper.jar` automatically).
3. Run on a device or emulator with Android 8.0 (API 26) or higher.

## What it does
- **Select folder** uses `ACTION_OPEN_DOCUMENT_TREE` and keeps access with `takePersistableUriPermission`.
  The URI is saved in DataStore and re-validated every time the app resumes.
- **Scan** looks up to 3 levels deep for `.exe` files; one whose name contains "ben10" marks the folder as detected.
  This is a heuristic. Adjust `FolderScanner.kt` if your copy uses a different layout.
- **Game info and compatibility** are in `data/Models.kt` (`GameInfo`). The suggested settings are starting points, not tested results.
- **Launch** opens the emulator (default package `com.winlator`, Cmod fork or any custom package) and copies the
  real folder path (e.g. `/storage/emulated/0/Games/Ben10`) to the clipboard.

## Important limits
- Winlator cannot read SAF `content://` URIs and has no public intent to start a specific game.
  After it opens, map the copied path as a drive in a container and start the `.exe` there.
  If your emulator fork supports launch intents or shortcuts, add them in `EmulatorLauncher.launch()`.
- The emulator needs its own storage permission (All files access) to read the folder.
- Paths can only be derived for internal storage and SD cards, not cloud providers.

## Structure
```
app/src/main/java/com/example/ben10launcher/
  MainActivity.kt          entry point
  LauncherViewModel.kt     state, SAF permission handling
  data/                    SettingsRepository, FolderScanner, EmulatorLauncher, Models
  ui/LauncherScreen.kt     Compose UI
  ui/theme/Theme.kt        Material 3 theme
```
