package com.example.ben10launcher

import android.app.Application
import android.content.Intent
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ben10launcher.data.EmulatorInfo
import com.example.ben10launcher.data.EmulatorLauncher
import com.example.ben10launcher.data.GameInfo
import com.example.ben10launcher.data.GameScanner
import com.example.ben10launcher.data.SettingsStore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class UiState(
    val treeUri: Uri? = null,
    val filePath: String? = null,
    val info: GameInfo? = null,
    val scanning: Boolean = false,
    val emulator: EmulatorInfo? = null,
    val apps: List<EmulatorInfo> = emptyList(),
    val customEmulator: String = "",
    val message: String? = null,
)

class LauncherViewModel(private val app: Application) : AndroidViewModel(app) {
    private val store = SettingsStore(app)
    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            store.customEmulator.collect { custom ->
                _state.update { it.copy(customEmulator = custom.orEmpty()) }
                refreshEmulator()
            }
        }
        viewModelScope.launch {
            store.treeUri.collect { uri ->
                _state.update { it.copy(treeUri = uri, filePath = uri?.let(GameScanner::toFilePath), info = null) }
                if (uri != null) rescan()
            }
        }
    }

    fun onFolderPicked(uri: Uri) {
        val resolver = app.contentResolver
        // Release the previous grant so we don't hit the persisted-permission limit.
        _state.value.treeUri?.takeIf { it != uri }?.let {
            runCatching { resolver.releasePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        }
        val ok = runCatching {
            resolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }.isSuccess
        if (!ok) {
            toast("Couldn't keep access to that folder. Try another location.")
            return
        }
        viewModelScope.launch { store.setTreeUri(uri) }
    }

    fun clearFolder() {
        _state.value.treeUri?.let {
            runCatching { app.contentResolver.releasePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        }
        viewModelScope.launch { store.setTreeUri(null) }
        _state.update { it.copy(info = null, filePath = null) }
    }

    fun rescan() {
        val uri = _state.value.treeUri ?: return
        viewModelScope.launch {
            _state.update { it.copy(scanning = true) }
            val info = GameScanner.scan(app, uri)
            _state.update { it.copy(info = info, scanning = false) }
        }
    }

    fun refreshEmulator() {
        _state.update {
            it.copy(
                emulator = EmulatorLauncher.findInstalled(app, it.customEmulator),
                apps = EmulatorLauncher.listLaunchable(app),
            )
        }
    }

    fun setCustomEmulator(pkg: String) {
        viewModelScope.launch { store.setCustomEmulator(pkg) }
    }

    fun resetEmulator() = setCustomEmulator("")

    fun launchEmulator() {
        val s = _state.value
        val emu = s.emulator ?: return
        val ok = EmulatorLauncher.launch(app, emu, s.filePath)
        toast(
            when {
                !ok -> "Couldn't open ${emu.label}."
                s.filePath != null -> "Game path copied. Paste it in ${emu.label}."
                else -> "Opening ${emu.label}…"
            }
        )
    }

    fun openDownloadPage() = EmulatorLauncher.openDownloadPage(app)
    fun consumeMessage() = _state.update { it.copy(message = null) }
    private fun toast(m: String) = _state.update { it.copy(message = m) }
}
