package com.example.ben10launcher.data

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import androidx.documentfile.provider.DocumentFile

/** Inspects the folder the user picked through the Storage Access Framework. */
object FolderScanner {
    private const val MAX_DEPTH = 3
    private const val MAX_ENTRIES = 500
    private val ignoredExeParts = listOf("unins", "crash", "vcredist", "dxsetup", "redist")

    fun scan(context: Context, uriString: String?): FolderScanResult {
        if (uriString.isNullOrBlank()) return FolderScanResult()

        val uri = Uri.parse(uriString)
        val hasPermission = context.contentResolver.persistedUriPermissions
            .any { it.uri == uri && it.isReadPermission }
        if (!hasPermission) {
            return FolderScanResult(
                status = FolderStatus.PERMISSION_LOST,
                message = "Access to this folder was revoked. Select it again.",
            )
        }

        val root = DocumentFile.fromTreeUri(context, uri)
        if (root == null || !root.exists() || !root.isDirectory) {
            return FolderScanResult(
                status = FolderStatus.FOLDER_MISSING,
                message = "The folder no longer exists or the drive is not connected.",
            )
        }

        val exes = findExecutables(root)
        val candidates = exes.filter { path ->
            val n = path.substringAfterLast('/').lowercase()
            ignoredExeParts.none { n.contains(it) }
        }
        val match = candidates.firstOrNull { normalize(it.substringAfterLast('/')).contains("ben10") }
        val real = resolveRealPath(uri)

        return when {
            match != null -> FolderScanResult(
                status = FolderStatus.VALID,
                message = "Ben 10 executable found.",
                displayName = root.name,
                primaryExe = match,
                exeCount = exes.size,
                realPath = real,
            )
            candidates.isNotEmpty() -> FolderScanResult(
                status = FolderStatus.POSSIBLE,
                message = "Found ${candidates.size} .exe file(s) but none look like Ben 10. " +
                    "You can still try launching if this is the right folder.",
                displayName = root.name,
                primaryExe = null,
                exeCount = exes.size,
                realPath = real,
            )
            else -> FolderScanResult(
                status = FolderStatus.NOT_FOUND,
                message = "No .exe files found. Pick the folder that contains the game.",
                displayName = root.name,
                realPath = real,
            )
        }
    }

    private fun findExecutables(root: DocumentFile): List<String> {
        val result = mutableListOf<String>()
        val queue = ArrayDeque<Triple<DocumentFile, String, Int>>()
        queue.add(Triple(root, "", 0))
        var visited = 0
        while (queue.isNotEmpty() && visited < MAX_ENTRIES) {
            val (dir, path, depth) = queue.removeFirst()
            for (child in dir.listFiles()) {
                visited++
                val name = child.name ?: continue
                if (child.isDirectory) {
                    if (depth < MAX_DEPTH) queue.add(Triple(child, "$path$name/", depth + 1))
                } else if (name.endsWith(".exe", ignoreCase = true)) {
                    result += "$path$name"
                }
            }
        }
        return result
    }

    private fun normalize(s: String) = s.lowercase().filter { it.isLetterOrDigit() }

    /**
     * Converts an external-storage tree URI into a normal path such as
     * /storage/emulated/0/Games/Ben10. Emulators like Winlator need this path,
     * because they cannot read SAF URIs. Returns null for cloud or other providers.
     */
    fun resolveRealPath(uri: Uri): String? = try {
        if (uri.authority != "com.android.externalstorage.documents") {
            null
        } else {
            val docId = DocumentsContract.getTreeDocumentId(uri)
            val volume = docId.substringBefore(':')
            val relative = docId.substringAfter(':', "")
            val base = if (volume.equals("primary", ignoreCase = true)) {
                "/storage/emulated/0"
            } else {
                "/storage/$volume"
            }
            if (relative.isEmpty()) base else "$base/$relative"
        }
    } catch (e: Exception) {
        null
    }
}
