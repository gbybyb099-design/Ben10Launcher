package com.example.ben10launcher

import android.app.Application
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ben10launcher.data.EmulatorLauncher
import com.example.ben10launcher.data.FolderScanResult
import com.example.ben10launcher.data.FolderScanner
import com.example.ben10launcher.data.LaunchResult
import com.example.ben10launcher.data.LauncherSettings
import com.example.ben10launcher.data.SettingsRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class UiState(
    val loading: Boolean = true,
    val settings: LauncherSettings = LauncherSettings(),
    val scan: FolderScanResult = FolderScanResult(),
    val emulatorInstalled: Boolean = false,
    val message: String? = null,
)

class LauncherViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = SettingsRepository(app)
    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            repo.settings.collect { s -> scanAndUpdate(s) }
        }
    }

    fun refresh() {
        viewModelScope.launch { scanAndUpdate(_state.value.settings) }
    }

    private suspend fun scanAndUpdate(s: LauncherSettings) {
        val app = getApplication<Application>()
        val scan = withContext(Dispatchers.IO) { FolderScanner.scan(app, s.folderUri) }
        val installed = EmulatorLauncher.isInstalled(app, s.emulatorPackage)
        _state.update {
            it.copy(loading = false, settings = s, scan = scan, emulatorInstalled = installed)
        }
    }

    fun onFolderPicked(uri: Uri) {
        val resolver = getApplication<Application>().contentResolver
        val rw = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
        try {
            resolver.takePersistableUriPermission(uri, rw)
        } catch (e: SecurityException) {
            try {
                resolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (e2: SecurityException) {
                toast("Could not save access to that folder.")
                return
            }
        }
        _state.value.settings.folderUri?.let { old ->
            if (old != uri.toString()) release(old)
        }
        viewModelScope.launch {
            repo.saveFolder(uri.toString())
            toast("Folder saved.")
        }
    }

    fun clearFolder() {
        _state.value.settings.folderUri?.let { release(it) }
        viewModelScope.launch {
            repo.saveFolder(null)
            toast("Folder removed.")
        }
    }

    private fun release(uriString: String) {
        try {
            val resolver = getApplication<Application>().contentResolver
            val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            resolver.releasePersistableUriPermission(Uri.parse(uriString), flags)
        } catch (e: Exception) {
            // Permission was already gone; nothing to do.
        }
    }

    fun setEmulator(packageName: String) {
        viewModelScope.launch { repo.saveEmulator(packageName) }
    }

    fun copyPath() {
        val path = _state.value.scan.realPath
        if (path == null) {
            toast("Path is not available for this storage location.")
        } else {
            copyToClipboard(path)
            toast("Path copied.")
        }
    }

    fun launchGame() {
        val s = _state.value
        val path = s.scan.realPath
        if (path != null) copyToClipboard(path)
        when (val r = EmulatorLauncher.launch(getApplication(), s.settings.emulatorPackage)) {
            LaunchResult.Success -> toast(
                if (path != null) "Emulator opened. Game folder path copied to clipboard."
                else "Emulator opened.",
            )
            LaunchResult.NotInstalled -> toast("Emulator is not installed.")
            is LaunchResult.Error -> toast(r.reason)
        }
    }

    fun consumeMessage() = _state.update { it.copy(message = null) }

    private fun toast(msg: String) = _state.update { it.copy(message = msg) }

    private fun copyToClipboard(text: String) {
        val cm = getApplication<Application>().getSystemService(ClipboardManager::class.java)
        cm.setPrimaryClip(ClipData.newPlainText("Game folder", text))
    }
}
