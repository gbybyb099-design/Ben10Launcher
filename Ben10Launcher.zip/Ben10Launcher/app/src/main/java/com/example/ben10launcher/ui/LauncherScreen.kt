package com.example.ben10launcher.ui

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ben10launcher.LauncherViewModel
import com.example.ben10launcher.data.Emulators
import com.example.ben10launcher.data.FolderScanResult
import com.example.ben10launcher.data.FolderStatus
import com.example.ben10launcher.data.GameInfo

private enum class Kind { OK, WARN, ERROR, NEUTRAL }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LauncherScreen(vm: LauncherViewModel = viewModel()) {
    val state by vm.state.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) vm.onFolderPicked(uri)
    }

    // Re-check after returning from the emulator or from installing it.
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { vm.refresh() }

    LaunchedEffect(state.message) {
        state.message?.let {
            snackbar.showSnackbar(it)
            vm.consumeMessage()
        }
    }

    val scan = state.scan
    val folderOk = scan.status == FolderStatus.VALID || scan.status == FolderStatus.POSSIBLE
    val canLaunch = folderOk && state.emulatorInstalled
    val emuLabel = Emulators.labelFor(state.settings.emulatorPackage)

    Scaffold(
        topBar = { CenterAlignedTopAppBar(title = { Text("Ben 10 Launcher") }) },
        snackbarHost = { SnackbarHost(snackbar) },
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            GameInfoCard()

            SectionCard("Game folder") {
                val (label, kind) = scan.chip()
                StatusChip(label, kind)
                Text(scan.message, style = MaterialTheme.typography.bodyMedium)
                scan.displayName?.let { InfoRow("Folder", it) }
                scan.primaryExe?.let { InfoRow("Detected", it) }
                scan.realPath?.let { InfoRow("Path", it) }
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Button(onClick = { picker.launch(null) }) {
                        Text(if (state.settings.folderUri == null) "Select folder" else "Change folder")
                    }
                    if (state.settings.folderUri != null) {
                        TextButton(onClick = vm::refresh) { Text("Rescan") }
                        if (scan.realPath != null) TextButton(onClick = vm::copyPath) { Text("Copy path") }
                        TextButton(onClick = vm::clearFolder) { Text("Remove") }
                    }
                }
            }

            CompatibilityCard(folderOk = folderOk, emulatorInstalled = state.emulatorInstalled)

            EmulatorCard(
                packageName = state.settings.emulatorPackage,
                installed = state.emulatorInstalled,
                onChange = vm::setEmulator,
            )

            Button(
                onClick = vm::launchGame,
                enabled = canLaunch,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
            ) {
                Icon(Icons.Default.PlayArrow, contentDescription = null)
                Text("Launch with $emuLabel", modifier = Modifier.padding(start = 8.dp))
            }

            Text(
                "Use only a game you own legally. This app contains no game files and never copies or uploads your data.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun GameInfoCard() {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
                GameInfo.TITLE,
                style = MaterialTheme.typography.headlineLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onPrimaryContainer,
            )
            Text(
                "${GameInfo.PLATFORM} · ${GameInfo.YEAR} · ${GameInfo.PUBLISHER}",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onPrimaryContainer,
            )
            Text(
                GameInfo.DESCRIPTION,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onPrimaryContainer,
            )
        }
    }
}

@Composable
private fun CompatibilityCard(folderOk: Boolean, emulatorInstalled: Boolean) {
    SectionCard("Compatibility") {
        val (text, kind) = when {
            !folderOk -> "Select your game folder" to Kind.WARN
            !emulatorInstalled -> "Emulator not installed" to Kind.WARN
            else -> "Ready to launch" to Kind.OK
        }
        StatusChip(text, kind)
        Text(
            "Windows games on Android depend on your device and the emulator version. " +
                "Results for this game are not verified, so expect to tweak settings.",
            style = MaterialTheme.typography.bodyMedium,
        )
        Text("Settings to try first", style = MaterialTheme.typography.titleSmall)
        GameInfo.suggestedSettings.forEach { (k, v) -> InfoRow(k, v) }
    }
}

@Composable
private fun EmulatorCard(packageName: String, installed: Boolean, onChange: (String) -> Unit) {
    val context = LocalContext.current
    val known = Emulators.known.firstOrNull { it.packageName == packageName }
    val isCustom = known == null

    SectionCard("Emulator") {
        StatusChip(if (installed) "Installed" else "Not installed", if (installed) Kind.OK else Kind.ERROR)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Emulators.known.forEach { opt ->
                FilterChip(
                    selected = packageName == opt.packageName,
                    onClick = { onChange(opt.packageName) },
                    label = { Text(opt.label) },
                )
            }
            FilterChip(
                selected = isCustom,
                onClick = { if (!isCustom) onChange("") },
                label = { Text("Custom") },
            )
        }
        if (isCustom) {
            var custom by remember { mutableStateOf(packageName) }
            OutlinedTextField(
                value = custom,
                onValueChange = {
                    custom = it
                    onChange(it.trim())
                },
                label = { Text("Package name") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
        }
        if (!installed) {
            OutlinedButton(onClick = {
                context.startActivity(
                    Intent(Intent.ACTION_VIEW, Uri.parse(Emulators.DOWNLOAD_URL))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                )
            }) { Text("Get Winlator") }
        }
    }
}

@Composable
private fun SectionCard(title: String, content: @Composable () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            content()
        }
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(
            value,
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier
                .padding(start = 16.dp)
                .weight(1f, fill = false),
        )
    }
}

@Composable
private fun StatusChip(text: String, kind: Kind) {
    val scheme = MaterialTheme.colorScheme
    val (bg, fg) = when (kind) {
        Kind.OK -> scheme.primaryContainer to scheme.onPrimaryContainer
        Kind.WARN -> scheme.tertiaryContainer to scheme.onTertiaryContainer
        Kind.ERROR -> scheme.errorContainer to scheme.onErrorContainer
        Kind.NEUTRAL -> scheme.surfaceVariant to scheme.onSurfaceVariant
    }
    val icon: ImageVector = when (kind) {
        Kind.OK -> Icons.Default.CheckCircle
        Kind.WARN, Kind.ERROR -> Icons.Default.Warning
        Kind.NEUTRAL -> Icons.Default.Info
    }
    Surface(color = bg, contentColor = fg, shape = RoundedCornerShape(50)) {
        Row(
            Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Icon(icon, contentDescription = null, modifier = Modifier.size(16.dp))
            Text(text, style = MaterialTheme.typography.labelLarge)
        }
    }
}

private fun FolderScanResult.chip(): Pair<String, Kind> = when (status) {
    FolderStatus.NONE -> "Not selected" to Kind.NEUTRAL
    FolderStatus.PERMISSION_LOST -> "Access lost" to Kind.ERROR
    FolderStatus.FOLDER_MISSING -> "Folder missing" to Kind.ERROR
    FolderStatus.NOT_FOUND -> "No game found" to Kind.ERROR
    FolderStatus.POSSIBLE -> "Unrecognised files" to Kind.WARN
    FolderStatus.VALID -> "Game detected" to Kind.OK
}
