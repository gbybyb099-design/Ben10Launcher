package com.example.ben10launcher.data

import android.content.Context
import android.content.Intent

sealed interface LaunchResult {
    data object Success : LaunchResult
    data object NotInstalled : LaunchResult
    data class Error(val reason: String) : LaunchResult
}

object EmulatorLauncher {

    fun isInstalled(context: Context, packageName: String): Boolean =
        packageName.isNotBlank() &&
            context.packageManager.getLaunchIntentForPackage(packageName) != null

    /**
     * Opens the emulator app. Winlator has no public API for starting a specific
     * game from another app, so the user finishes from inside the emulator
     * (the folder path is copied to the clipboard to help with that).
     */
    fun launch(context: Context, packageName: String): LaunchResult {
        val intent = packageName.takeIf { it.isNotBlank() }
            ?.let { context.packageManager.getLaunchIntentForPackage(it) }
            ?: return LaunchResult.NotInstalled
        return try {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            LaunchResult.Success
        } catch (e: Exception) {
            LaunchResult.Error(e.message ?: "Could not open the emulator.")
        }
    }
}
