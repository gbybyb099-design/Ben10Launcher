package com.example.ben10launcher.data

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

enum class CompatStatus { NO_FOLDER, INACCESSIBLE, NOT_RECOGNIZED, PARTIAL, LOOKS_VALID }

data class GameInfo(
    val folderName: String,
    val executables: List<String>,
    val hasEngineDir: Boolean,
    val hasGameDir: Boolean,
    val pakCount: Int,
    val pakBytes: Long,
    val status: CompatStatus,
)

/**
 * Inspects the chosen folder with SAF. Detection is heuristic (the game is an Unreal Engine 4 title):
 * a root .exe, an "Engine" folder, and a game folder with Content/Paks/*.pak.
 * It only reads folder structure; it never copies or modifies game files.
 */
object GameScanner {

    suspend fun scan(context: Context, uri: Uri): GameInfo = withContext(Dispatchers.IO) {
        val root = DocumentFile.fromTreeUri(context, uri)
        if (root == null || !root.exists() || !root.canRead()) {
            return@withContext GameInfo(root?.name ?: "Unknown", emptyList(), false, false, 0, 0, CompatStatus.INACCESSIBLE)
        }
        val children = root.listFiles()
        val exes = children.filter { it.isFile && it.name.orEmpty().endsWith(".exe", true) }
            .mapNotNull { it.name }
        val hasEngine = children.any { it.isDirectory && it.name.equals("Engine", true) }

        var gameDir = false
        var paks = emptyList<DocumentFile>()
        for (dir in children.filter { it.isDirectory && !it.name.equals("Engine", true) }) {
            val paksDir = dir.findFile("Content")?.findFile("Paks")
            if (paksDir != null && paksDir.isDirectory) {
                gameDir = true
                paks = paksDir.listFiles().filter { it.name.orEmpty().endsWith(".pak", true) }
                break
            }
        }

        val score = listOf(exes.isNotEmpty(), hasEngine, gameDir && paks.isNotEmpty()).count { it }
        val status = when {
            score >= 2 && paks.isNotEmpty() -> CompatStatus.LOOKS_VALID
            score >= 1 -> CompatStatus.PARTIAL
            else -> CompatStatus.NOT_RECOGNIZED
        }
        GameInfo(root.name ?: "Game folder", exes, hasEngine, gameDir, paks.size, paks.sumOf { it.length() }, status)
    }

    /**
     * Best-effort conversion of a SAF tree URI to a real path (e.g. /storage/emulated/0/Games/Ben10),
     * which is what Winlator's file picker needs. Returns null if it can't be derived.
     */
    fun toFilePath(uri: Uri): String? = runCatching {
        val docId = DocumentsContract.getTreeDocumentId(uri)
        val parts = docId.split(":", limit = 2)
        val volume = parts[0]
        val rel = parts.getOrElse(1) { "" }
        when (volume) {
            "primary" -> "/storage/emulated/0/$rel".trimEnd('/')
            else -> "/storage/$volume/$rel".trimEnd('/')
        }
    }.getOrNull()
}
