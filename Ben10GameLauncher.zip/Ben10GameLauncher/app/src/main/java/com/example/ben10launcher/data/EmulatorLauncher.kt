package com.example.ben10launcher.data

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri

data class EmulatorInfo(val packageName: String, val label: String)

object EmulatorLauncher {
    const val WINLATOR_RELEASES = "https://github.com/brunodev85/winlator/releases"

    /** Known Winlator builds/forks. The user can also provide a custom package name. */
    private val knownPackages = listOf(
        "com.winlator",
        "com.winlator.cmod",
        "com.winlator.glibc",
        "com.winlator.ludashi",
    )

    /** Every app with a launcher icon (except this one), sorted by name. */
    fun listLaunchable(context: Context): List<EmulatorInfo> {
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, 0)
            .map { EmulatorInfo(it.activityInfo.packageName, it.loadLabel(pm).toString()) }
            .filter { it.packageName != context.packageName }
            .distinctBy { it.packageName }
            .sortedBy { it.label.lowercase() }
    }

    fun isWinlatorLike(app: EmulatorInfo) =
        app.label.contains("winlator", true) || app.packageName.contains("winlator", true)

    /** Order: the app the user picked, then known Winlator packages, then any app named like Winlator. */
    fun findInstalled(context: Context, custom: String?): EmulatorInfo? {
        val pm = context.packageManager
        val all = listLaunchable(context)
        custom?.takeIf { it.isNotBlank() }?.let { pkg ->
            all.firstOrNull { it.packageName == pkg }?.let { return it }
        }
        for (pkg in knownPackages) all.firstOrNull { it.packageName == pkg }?.let { return it }
        return all.firstOrNull(::isWinlatorLike)
    }

    /**
     * Opens the emulator. Winlator has no stable public "run this exe" intent, so the game's
     * file path is copied to the clipboard to paste into Winlator's container/shortcut setup.
     */
    fun launch(context: Context, emulator: EmulatorInfo, gamePath: String?): Boolean {
        val intent = context.packageManager.getLaunchIntentForPackage(emulator.packageName) ?: return false
        if (gamePath != null) {
            val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("Ben 10 game path", gamePath))
        }
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return runCatching { context.startActivity(intent) }.isSuccess
    }

    fun openDownloadPage(context: Context) {
        val i = Intent(Intent.ACTION_VIEW, Uri.parse(WINLATOR_RELEASES)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        runCatching { context.startActivity(i) }
    }
}
