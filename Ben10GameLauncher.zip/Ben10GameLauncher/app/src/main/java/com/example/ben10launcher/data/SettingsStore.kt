package com.example.ben10launcher.data

import android.content.Context
import android.net.Uri
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "launcher_settings")

/** Persists the selected game folder (SAF tree URI) and an optional custom emulator package. */
class SettingsStore(private val context: Context) {
    private val treeKey = stringPreferencesKey("game_tree_uri")
    private val emuKey = stringPreferencesKey("custom_emulator_package")

    val treeUri: Flow<Uri?> = context.dataStore.data.map { it[treeKey]?.let(Uri::parse) }
    val customEmulator: Flow<String?> = context.dataStore.data.map { it[emuKey] }

    suspend fun setTreeUri(uri: Uri?) {
        context.dataStore.edit {
            if (uri == null) it.remove(treeKey) else it[treeKey] = uri.toString()
        }
    }

    suspend fun setCustomEmulator(pkg: String?) {
        context.dataStore.edit {
            if (pkg.isNullOrBlank()) it.remove(emuKey) else it[emuKey] = pkg.trim()
        }
    }
}
