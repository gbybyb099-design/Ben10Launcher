package com.example.ben10launcher.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "launcher_settings")

class SettingsRepository(private val context: Context) {

    private object Keys {
        val FOLDER_URI = stringPreferencesKey("folder_uri")
        val EMULATOR = stringPreferencesKey("emulator_package")
    }

    val settings: Flow<LauncherSettings> = context.dataStore.data.map { p ->
        LauncherSettings(
            folderUri = p[Keys.FOLDER_URI],
            emulatorPackage = p[Keys.EMULATOR] ?: Emulators.DEFAULT_PACKAGE,
        )
    }

    suspend fun saveFolder(uri: String?) {
        context.dataStore.edit { p ->
            if (uri == null) p.remove(Keys.FOLDER_URI) else p[Keys.FOLDER_URI] = uri
        }
    }

    suspend fun saveEmulator(packageName: String) {
        context.dataStore.edit { p -> p[Keys.EMULATOR] = packageName }
    }
}
